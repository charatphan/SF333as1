package com.example.sf333as_1

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity


class MainActivity : ComponentActivity() {
    private var random = (1..1000).random()
    private var count = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }
    fun updateText(view: View?) {
        val editText = findViewById<EditText>(R.id.inputText);

        while (count >= 0) {
            val number  = editText.text.toString()
            val hi = "highter";
            val low = "lower"
            val ture = "you wrong is $count"
            if (number > random.toString()) {
                val txtview =  findViewById<TextView>(R.id.textView3).apply { text = hi}
                println("Button clicked")
                count = count++
            }
            if (number < random.toString()) {
                val txtview =  findViewById<TextView>(R.id.textView3).apply { text = low}
                println("Button clicked")
                count = count++
            }
            if (number.equals(random.toString())) {
                val txtview =  findViewById<TextView>(R.id.textView3).apply { text = ture}
                var random = (1..1000).random()
                println("Button clicked")
                count = 0
            }
        }
    }
}




